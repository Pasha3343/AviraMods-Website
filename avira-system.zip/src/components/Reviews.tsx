import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Star } from 'lucide-react';

const initialReviews = [
  {
    name: 'DarkShadow99',
    text: 'Das Crosshair System ist der Wahnsinn. Endlich ein Tool das alles in einem hat. 100%...',
    rating: 5,
  },
  {
    name: 'Niko_GTA',
    text: 'Super Programm, die PC Optimierung hat wirklich geholfen. BloodFX und Custom Himmel sind...',
    rating: 5,
  },
  {
    name: 'LenaGamer',
    text: 'Das Soundboard ist mein Highlight. Pasha macht das richtig! Freue mich auf die nächsten Updates.',
    rating: 5,
  },
  {
    name: 'TobiFPS',
    text: 'Endlich keine Ruckler mehr in FiveM. Der FPS Boost ist echt spürbar. Premium Edition war jeden Cent wert.',
    rating: 5,
  },
];

export default function Reviews() {
  const [allReviews, setAllReviews] = useState(initialReviews);
  const [newName, setNewName] = useState('');
  const [newText, setNewText] = useState('');
  const [newRating, setNewRating] = useState(5);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newText) return;

    const review = {
      name: newName,
      text: newText,
      rating: newRating,
    };

    setAllReviews([review, ...allReviews]);
    setNewName('');
    setNewText('');
    setNewRating(5);
  };
  return (
    <section id="reviews" className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-brand-purple text-xs font-bold tracking-widest uppercase mb-4 block">
            Community
          </span>
          <h2 className="text-4xl md:text-6xl font-black mb-6">Was die Community sagt</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Echte Bewertungen von echten Nutzern. Teile auch deine Erfahrung!
          </p>
        </div>

        <div className="relative overflow-hidden mb-20">
          <motion.div
            animate={{
              x: [0, -1000],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear",
            }}
            className="flex gap-6 w-max"
          >
            {[...allReviews, ...allReviews].map((review, index) => (
              <div
                key={index}
                className="liquid-glass p-8 rounded-3xl w-[300px] shrink-0 hover:border-brand-purple/50 transition-all group hover:shadow-glow-purple"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-brand-purple text-brand-purple glow-purple" />
                  ))}
                </div>
                <p className="text-sm text-gray-400 italic mb-6 leading-relaxed">
                  "{review.text}"
                </p>
                <div className="text-sm font-bold text-brand-purple glow-purple">{review.name}</div>
              </div>
            ))}
          </motion.div>
          {/* Fades */}
          <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-[#050505] to-transparent z-10" />
          <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-[#050505] to-transparent z-10" />
        </div>

        <div className="max-w-2xl mx-auto liquid-glass p-10 rounded-[40px] border-brand-purple/30 shadow-glow-white">
          <h3 className="text-2xl font-bold mb-8 glow-white">Deine Bewertung</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 mb-2">
                  Dein Name
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="z.B. xPashaY"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-purple transition-colors shadow-inner"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 mb-2">
                  Bewertung
                </label>
                <div className="flex gap-2 py-2">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      onClick={() => setNewRating(i + 1)}
                      className={`w-6 h-6 cursor-pointer transition-colors ${i < newRating ? 'fill-brand-purple text-brand-purple' : 'text-gray-600'}`} 
                    />
                  ))}
                </div>
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 mb-2">
                Deine Nachricht
              </label>
              <textarea
                rows={4}
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                placeholder="Was denkst du über AviraMods?"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-purple transition-colors resize-none shadow-inner"
                required
              />
            </div>
            <button 
              type="submit"
              className="bg-brand-purple hover:bg-brand-purple-dark text-white px-8 py-4 rounded-2xl font-bold transition-all w-full sm:w-auto shadow-xl shadow-brand-purple/40 shadow-glow-purple"
            >
              Bewertung abschicken
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
