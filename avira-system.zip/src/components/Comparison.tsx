import React from 'react';
import { motion } from 'motion/react';

const mods = [
  { id: 'tracer', name: 'Tracer Effect', tag: 'Combat', desc: 'Visuelle Tracer-Effekte bei Schüssen — perfekt für Roleplay und Action-Server.' },
  { id: 'sky', name: 'Custom Himmel', tag: 'Visual', desc: 'Dramatische Himmel-Texturen die das Spiel komplett neu aussehen lassen.' },
  { id: 'road', name: 'Straßen Mod', tag: 'Textur', desc: 'HD Straßen-Texturen für ein realistischeres Fahrgefühl.' },
  { id: 'blood', name: 'BloodFX', tag: 'Effekte', desc: 'Realistische Blut-Effekte für ein immersives Gameplay-Erlebnis.' },
];

export default function Comparison() {
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-brand-purple text-xs font-bold tracking-widest uppercase mb-4 block">
            System Galerie
          </span>
          <h2 className="text-4xl md:text-6xl font-black mb-6 glow-white">Einblick in das System</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Hier siehst du exklusive Einblicke direkt aus dem AviraMods Interface.
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative aspect-video rounded-[40px] overflow-hidden border border-brand-purple/30 shadow-2xl shadow-glow-purple group bg-black"
          >
            <video
              autoPlay
              loop
              muted
              playsInline
              className="absolute inset-0 w-full h-full object-cover opacity-90"
            >
              <source src="/video.mp4" type="video/mp4" />
              <source src="https://cdn.pixabay.com/video/2021/09/06/87585-601431610_large.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
            <div className="absolute inset-0 bg-gradient-to-t from-brand-bg/60 via-transparent to-transparent pointer-events-none" />
            
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
              <div className="liquid-glass p-6 rounded-full shadow-glow-purple">
                <div className="w-12 h-12 bg-brand-purple rounded-full flex items-center justify-center">
                  <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1" />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
