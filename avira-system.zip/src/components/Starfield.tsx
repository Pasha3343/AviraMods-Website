import React, { useMemo } from 'react';

export default function Starfield() {
  const stars = useMemo(() => {
    return Array.from({ length: 300 }).map((_, i) => ({
      id: i,
      top: `${Math.random() * 100}%`,
      left: `${Math.random() * 100}%`,
      size: Math.random() * 2 + 0.5,
      duration: Math.random() * 3 + 2,
      delay: Math.random() * 5,
      opacity: Math.random() * 0.5 + 0.5,
    }));
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden bg-[#0d0d0f]">
      {/* Deep Space Glows - Multiple layers for depth and smoothness */}
      <div className="absolute top-[-25%] left-[-25%] w-[150%] h-[150%] bg-[radial-gradient(circle_at_30%_30%,rgba(139,92,246,0.02)_0%,transparent_70%)] animate-pulse-glow" />
      <div className="absolute bottom-[-25%] right-[-25%] w-[150%] h-[150%] bg-[radial-gradient(circle_at_70%_70%,rgba(139,92,246,0.015)_0%,transparent_70%)] animate-pulse-glow" style={{ animationDelay: '-7s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[160%] h-[160%] bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.005)_0%,transparent_60%)]" />
      
      {stars.map((star) => (
        <div
          key={star.id}
          className="absolute rounded-full animate-twinkle bg-white"
          style={{
            top: star.top,
            left: star.left,
            width: `${star.size}px`,
            height: `${star.size}px`,
            boxShadow: `0 0 ${star.size * 3}px rgba(255, 255, 255, 0.8)`,
            opacity: star.opacity,
            '--duration': `${star.duration}s`,
            animationDelay: `${star.delay}s`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
}
