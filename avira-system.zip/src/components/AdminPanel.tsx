import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Settings, Plus, Trash2, Save, LogIn, LogOut, Globe, Download, Info } from 'lucide-react';
import { useFirebase } from '../lib/FirebaseContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, setDoc, collection, addDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';

export default function AdminPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [code, setCode] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { user, config, downloads, login, logout } = useFirebase();
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Form states
  const [discordLink, setDiscordLink] = useState('');
  const [stats, setStats] = useState({
    downloads: '5.000+',
    members: '1.200+',
    satisfaction: '99%'
  });
  const [newDownload, setNewDownload] = useState({
    version: '',
    title: '',
    description: '',
    downloadUrl: '',
    isCurrent: true
  });

  useEffect(() => {
    if (config) {
      setDiscordLink(config.discordLink);
      if (config.stats) setStats(config.stats);
    }
  }, [config]);

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
  };

  const handleCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code === 'ChewaDoko1974.') {
      setIsAuthenticated(true);
    } else {
      showNotification('Falscher Code! Bitte überprüfe deine Eingabe.', 'error');
    }
  };

  const updateConfig = async () => {
    if (!user || !isAdmin) {
      showNotification('Du musst als Admin eingeloggt sein (xxgammeryt@gmail.com)!', 'error');
      return;
    }
    const path = 'config/global';
    try {
      await setDoc(doc(db, 'config', 'global'), {
        discordLink,
        updatedAt: serverTimestamp()
      }, { merge: true });
      showNotification('Discord Link erfolgreich aktualisiert!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const updateStats = async () => {
    if (!user || !isAdmin) {
      showNotification('Du musst als Admin eingeloggt sein (xxgammeryt@gmail.com)!', 'error');
      return;
    }
    const path = 'config/global';
    try {
      await setDoc(doc(db, 'config', 'global'), {
        stats,
        updatedAt: serverTimestamp()
      }, { merge: true });
      showNotification('Statistiken erfolgreich aktualisiert!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const addDownload = async () => {
    if (!user || !isAdmin) {
      showNotification('Du musst als Admin eingeloggt sein (xxgammeryt@gmail.com)!', 'error');
      return;
    }
    if (!newDownload.version || !newDownload.title || !newDownload.description || !newDownload.downloadUrl) {
      showNotification('Bitte fülle alle Felder aus!', 'error');
      return;
    }
    const path = 'downloads';
    try {
      await addDoc(collection(db, 'downloads'), {
        version: newDownload.version,
        title: newDownload.title,
        description: newDownload.description,
        downloadUrl: newDownload.downloadUrl,
        isCurrent: true,
        createdAt: serverTimestamp()
      });
      setNewDownload({
        version: '',
        title: '',
        description: '',
        downloadUrl: '',
        isCurrent: true
      });
      showNotification('Version erfolgreich hinzugefügt!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const removeDownload = async (id: string) => {
    if (!user || !isAdmin) {
      showNotification('Du musst als Admin eingeloggt sein (xxgammeryt@gmail.com)!', 'error');
      return;
    }
    const path = `downloads/${id}`;
    try {
      await deleteDoc(doc(db, 'downloads', id));
      showNotification('Version gelöscht.');
      setConfirmDeleteId(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  const isAdmin = user?.email === 'xxgammeryt@gmail.com';

  useEffect(() => {
    (window as any).openAdminPanel = () => setIsOpen(true);
    return () => { delete (window as any).openAdminPanel; };
  }, []);

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="absolute inset-0 bg-black/95 backdrop-blur-xl"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-4xl liquid-glass p-8 rounded-[40px] border-brand-purple/50 shadow-2xl shadow-glow-purple max-h-[90vh] overflow-y-auto"
            >
              <button
                onClick={() => setIsOpen(false)}
                className="absolute top-6 right-6 text-gray-500 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>

              {!isAuthenticated ? (
                <div className="max-w-md mx-auto text-center py-20">
                  <Settings className="w-16 h-16 text-brand-purple mx-auto mb-6 animate-spin-slow" />
                  <h2 className="text-3xl font-black mb-8">Admin Zugang</h2>
                  <form onSubmit={handleCodeSubmit} className="space-y-4">
                    <input 
                      type="password"
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      placeholder="Admin Code eingeben..."
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:border-brand-purple outline-none transition-all"
                      autoFocus
                    />
                    <button className="w-full bg-brand-purple text-white py-4 rounded-2xl font-bold shadow-lg shadow-brand-purple/40">
                      Einloggen
                    </button>
                  </form>
                </div>
              ) : (
                <div className="space-y-12">
                  <div className="flex items-center justify-between border-b border-white/10 pb-6">
                    <div>
                      <h2 className="text-3xl font-black glow-white">Admin Panel</h2>
                      <p className="text-gray-500 text-sm">Verwalte deine Website-Inhalte</p>
                    </div>
                    <div className="flex items-center gap-4">
                      {user ? (
                        <div className="flex items-center gap-4">
                          <span className="text-xs font-bold text-gray-400">{user.email}</span>
                          <button onClick={logout} className="text-red-400 hover:text-red-300 flex items-center gap-1 text-xs font-bold">
                            <LogOut className="w-4 h-4" /> Logout
                          </button>
                        </div>
                      ) : (
                        <button onClick={login} className="bg-white/10 hover:bg-white/20 px-6 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
                          <LogIn className="w-4 h-4" /> Mit Google anmelden
                        </button>
                      )}
                    </div>
                  </div>

                  {!isAdmin && user && (
                    <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl text-red-500 text-sm font-bold flex items-center gap-3">
                      <Info className="w-5 h-5" />
                      Du bist zwar eingeloggt, hast aber keine Admin-Rechte für die Datenbank.
                    </div>
                  )}

                  {/* Discord Config */}
                  <div className="grid md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <h3 className="text-xl font-bold flex items-center gap-2">
                        <Globe className="w-5 h-5 text-brand-purple" /> Discord Server Link
                      </h3>
                      <div className="flex gap-4">
                        <input 
                          type="text"
                          value={discordLink}
                          onChange={(e) => setDiscordLink(e.target.value)}
                          placeholder="https://discord.gg/..."
                          className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:border-brand-purple outline-none transition-all"
                        />
                        <button 
                          onClick={updateConfig}
                          disabled={!isAdmin}
                          className="bg-brand-purple disabled:opacity-50 px-8 rounded-2xl font-bold flex items-center gap-2"
                        >
                          <Save className="w-5 h-5" />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <h3 className="text-xl font-bold flex items-center gap-2">
                        <Settings className="w-5 h-5 text-brand-purple" /> Live Statistiken
                      </h3>
                      <div className="grid grid-cols-3 gap-3">
                        <div className="space-y-2">
                          <label className="text-[10px] font-bold text-gray-500 uppercase">Downloads</label>
                          <input 
                            value={stats.downloads}
                            onChange={e => setStats({...stats, downloads: e.target.value})}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none focus:border-brand-purple"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-bold text-gray-500 uppercase">Members</label>
                          <input 
                            value={stats.members}
                            onChange={e => setStats({...stats, members: e.target.value})}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none focus:border-brand-purple"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-bold text-gray-500 uppercase">Zufriedenheit</label>
                          <input 
                            value={stats.satisfaction}
                            onChange={e => setStats({...stats, satisfaction: e.target.value})}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none focus:border-brand-purple"
                          />
                        </div>
                      </div>
                      <button 
                        onClick={updateStats}
                        disabled={!isAdmin}
                        className="w-full bg-white/10 hover:bg-brand-purple py-3 rounded-xl font-bold transition-all disabled:opacity-50 text-sm"
                      >
                        Stats speichern
                      </button>
                    </div>
                  </div>

                  {/* Downloads Management */}
                  <div className="space-y-6">
                    <h3 className="text-xl font-bold flex items-center gap-2">
                      <Download className="w-5 h-5 text-brand-purple" /> Download Versionen
                    </h3>
                    
                    {/* Add New */}
                    <div className="liquid-glass p-6 rounded-3xl border-white/5 space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <input 
                          placeholder="Version (z.B. v1.2.0)"
                          value={newDownload.version}
                          onChange={e => setNewDownload({...newDownload, version: e.target.value})}
                          className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-brand-purple"
                        />
                        <input 
                          placeholder="Überschrift (z.B. April 2026)"
                          value={newDownload.title}
                          onChange={e => setNewDownload({...newDownload, title: e.target.value})}
                          className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-brand-purple"
                        />
                      </div>
                      <textarea 
                        placeholder="Beschreibung..."
                        value={newDownload.description}
                        onChange={e => setNewDownload({...newDownload, description: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-brand-purple h-24"
                      />
                      <input 
                        placeholder="Download Link (URL)"
                        value={newDownload.downloadUrl}
                        onChange={e => setNewDownload({...newDownload, downloadUrl: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-brand-purple"
                      />
                      <button 
                        onClick={addDownload}
                        disabled={!isAdmin}
                        className="w-full bg-white/10 hover:bg-brand-purple py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        <Plus className="w-5 h-5" /> Version hinzufügen
                      </button>
                    </div>

                    {/* List Existing */}
                    <div className="space-y-4">
                      {downloads.length === 0 ? (
                        <div className="text-center py-10 bg-white/5 rounded-3xl border border-dashed border-white/10">
                          <p className="text-gray-500 text-sm italic">Noch keine Versionen in der Datenbank vorhanden.</p>
                        </div>
                      ) : (
                        downloads.map(dl => (
                          <div key={dl.id} className="flex items-center justify-between p-5 glass rounded-2xl border-white/5 hover:border-white/10 transition-all">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-xl bg-brand-purple/10 flex items-center justify-center text-brand-purple">
                                <Download className="w-5 h-5" />
                              </div>
                              <div>
                                <div className="font-bold text-white flex items-center gap-2">
                                  {dl.title} 
                                  <span className="text-[10px] font-black bg-brand-purple/20 text-brand-purple px-2 py-0.5 rounded uppercase tracking-widest">
                                    {dl.version}
                                  </span>
                                </div>
                                <div className="text-[10px] text-gray-500 truncate max-w-[200px] md:max-w-md mt-1">{dl.downloadUrl}</div>
                              </div>
                            </div>
                            <button 
                              onClick={() => setConfirmDeleteId(dl.id)}
                              disabled={!isAdmin}
                              className="p-3 text-red-500 hover:bg-red-500/10 rounded-xl transition-all disabled:opacity-50"
                              title="Löschen"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Notification Toast */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-10 left-1/2 -translate-x-1/2 z-[300] px-6 py-3 rounded-2xl font-bold shadow-2xl flex items-center gap-3 ${
              notification.type === 'success' ? 'bg-green-500 text-white shadow-green-500/20' : 'bg-red-500 text-white shadow-red-500/20'
            }`}
          >
            {notification.message}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {confirmDeleteId && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setConfirmDeleteId(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative bg-[#111113] border border-white/10 p-8 rounded-[32px] max-w-sm w-full text-center shadow-2xl"
            >
              <Trash2 className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Version löschen?</h3>
              <p className="text-gray-500 text-sm mb-8">Diese Aktion kann nicht rückgängig gemacht werden.</p>
              <div className="flex gap-4">
                <button 
                  onClick={() => setConfirmDeleteId(null)}
                  className="flex-1 bg-white/5 hover:bg-white/10 py-3 rounded-xl font-bold transition-all"
                >
                  Abbrechen
                </button>
                <button 
                  onClick={() => removeDownload(confirmDeleteId)}
                  className="flex-1 bg-red-500 hover:bg-red-600 py-3 rounded-xl font-bold transition-all"
                >
                  Löschen
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
