import { motion } from 'motion/react';
import { Shield, Zap, Palette, Music, Crosshair, Plus } from 'lucide-react';

const features = [
  {
    title: 'FiveM Modifikationen',
    desc: 'Tracer, Custom Himmel, BloodFX, Waffen-Skins & mehr',
    icon: Zap,
  },
  {
    title: 'PC Optimierung',
    desc: 'Mehr Speicher, mehr FPS, volle Leistung für dein PC',
    icon: Shield,
  },
  {
    title: 'Grafik & Visuell',
    desc: 'Blut-Effekte, Radarkarte, Beleuchtung, Texturen',
    icon: Palette,
  },
  {
    title: 'Soundboard System',
    desc: 'Eigene Sounds, Hotkeys, Playlists, Effekte',
    icon: Music,
  },
  {
    title: 'Crosshair Editor',
    desc: 'Eigene Crosshairs erstellen oder Vorlagen nutzen',
    icon: Crosshair,
  },
  {
    title: '& Vieles mehr...',
    desc: 'Neue Features werden laufend hinzugefügt',
    icon: Plus,
  },
];

export default function Features() {
  return (
    <section id="features" className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <span className="text-brand-purple text-xs font-bold tracking-widest uppercase mb-4 block">
            Was Avira kann
          </span>
          <h2 className="text-4xl md:text-6xl font-black mb-6">Alles in einer App</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            AviraMods vereint alles was du als FiveM Spieler brauchst in einer einzigen Desktop-Anwendung. 
            Der Großteil ist komplett kostenlos — nur wenige Premium-Features erfordern die Premium Edition.
          </p>
        </div>

        {/* App Mockup Placeholder */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="relative mb-24 rounded-3xl overflow-hidden border border-brand-purple/30 shadow-2xl shadow-glow-purple animate-float"
        >
          <img
            src="/1.png"
            alt="Avira App Interface"
            className="w-full h-auto"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-bg/60 via-transparent to-transparent" />
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="liquid-glass p-8 rounded-3xl hover:border-brand-purple/50 transition-all group hover:shadow-glow-purple"
            >
              <div className="w-12 h-12 bg-brand-purple/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-purple/20 transition-colors shadow-inner">
                <feature.icon className="w-6 h-6 text-brand-purple glow-purple" />
              </div>
              <h3 className="text-xl font-bold mb-3 glow-white">{feature.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">
                {feature.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
