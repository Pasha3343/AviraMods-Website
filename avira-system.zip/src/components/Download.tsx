import { motion } from 'motion/react';
import { Download, Monitor, Shield, Zap } from 'lucide-react';
import { DiscordIcon } from './Icons';
import { useFirebase } from '../lib/FirebaseContext';

export default function DownloadSection() {
  const { config, downloads } = useFirebase();
  const discordLink = config?.discordLink || "https://discord.gg/fx3tumNgCB";
  
  // Get the latest download or use default
  const latestDownload = downloads.length > 0 ? downloads[0] : {
    version: 'v1.0.0-Beta',
    title: 'April 2026',
    description: 'Erster öffentlicher Beta-Release. FiveM Mods, PC-Optimierung, Crosshair System, Soundboard & Grafikmods.',
    downloadUrl: '#'
  };

  return (
    <section id="download" className="py-24 px-6 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] bg-brand-purple/10 blur-[200px] rounded-full -z-10" />
      
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-brand-purple text-xs font-bold tracking-widest uppercase mb-4 block">
            Download
          </span>
          <h2 className="text-4xl md:text-6xl font-black mb-6">Avira System herunterladen</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Lade die aktuellste Version herunter und werde Teil der ersten Nutzer.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto liquid-glass p-10 rounded-[40px] border-brand-purple/30 shadow-2xl shadow-glow-purple"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-brand-purple px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest shadow-xl shadow-brand-purple/40 glow-white">
                  {latestDownload.version}
                </div>
                <div className="text-xs font-bold text-brand-purple uppercase tracking-widest glow-purple">Aktuell</div>
              </div>
              
              <h3 className="text-3xl font-black mb-4 glow-white">{latestDownload.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed mb-8">
                {latestDownload.description}
              </p>
              
              <div className="flex flex-wrap gap-6 text-xs font-bold text-gray-500 uppercase tracking-widest">
                <div className="flex items-center gap-2">
                  <Monitor className="w-4 h-4 text-brand-purple" /> Plattform: Windows
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-brand-purple" /> Version: {latestDownload.version}
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-brand-purple" /> Entwickelt von Pasha
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center gap-4">
              <a 
                href={latestDownload.downloadUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-brand-purple hover:bg-brand-purple-dark text-white px-12 py-6 rounded-3xl font-black text-xl transition-all shadow-2xl shadow-brand-purple/60 shadow-glow-purple flex items-center gap-3 active:scale-95"
              >
                <Download className="w-6 h-6" />
                Download
              </a>
              <div className="text-[10px] text-gray-600 font-bold uppercase tracking-widest">
                Größe: ca. 45MB — .exe Installer
              </div>
            </div>
          </div>
        </motion.div>

        {/* Version History */}
        {downloads.length > 1 && (
          <div className="max-w-4xl mx-auto mt-16">
            <h4 className="text-xl font-bold mb-8 flex items-center gap-3">
              <div className="w-8 h-1 bg-brand-purple rounded-full" />
              Ältere Versionen
            </h4>
            <div className="grid gap-4">
              {downloads.slice(1).map((dl) => (
                <motion.div
                  key={dl.id}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="glass p-6 rounded-3xl border-white/5 flex flex-col md:flex-row items-center justify-between gap-6 hover:border-white/10 transition-all group"
                >
                  <div className="flex items-center gap-6">
                    <div className="bg-white/5 p-3 rounded-2xl group-hover:bg-brand-purple/10 transition-colors">
                      <Monitor className="w-6 h-6 text-gray-500 group-hover:text-brand-purple" />
                    </div>
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <span className="font-bold text-white">{dl.title}</span>
                        <span className="text-[10px] font-black bg-white/10 px-2 py-0.5 rounded text-gray-400 uppercase tracking-widest">
                          {dl.version}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 line-clamp-1">{dl.description}</p>
                    </div>
                  </div>
                  <a 
                    href={dl.downloadUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-white/5 hover:bg-white/10 px-6 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" /> Download
                  </a>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Discord Section */}
        <div className="mt-24 text-center">
          <a 
            href={discordLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-6 glass p-2 pr-8 rounded-full border-brand-purple/20 hover:border-brand-purple/50 transition-all shadow-glow-purple"
          >
            <div className="w-12 h-12 bg-brand-purple rounded-full flex items-center justify-center shadow-lg shadow-brand-purple/40">
              <DiscordIcon className="w-6 h-6 text-white" />
            </div>
            <div className="text-left">
              <div className="text-sm font-black">Tritt unserem Discord bei</div>
              <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">
                Erhalte alle News, Support & Feedback
              </div>
            </div>
            <div className="bg-brand-purple hover:bg-brand-purple-dark text-white px-6 py-2 rounded-full text-xs font-bold transition-all ml-4">
              Discord beitreten
            </div>
          </a>
        </div>
      </div>
    </section>
  );
}
