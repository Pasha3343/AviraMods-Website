import { motion } from 'motion/react';
import { Gift, Sparkles, Clock, Coins } from 'lucide-react';

export default function DailyReward() {
  return (
    <section id="daily-reward" className="py-24 px-6 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-purple/5 blur-[150px] rounded-full -z-10" />
      
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          
          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <span className="text-brand-purple text-xs font-bold tracking-widest uppercase mb-4 block">
                Daily Rewards
              </span>
              <h2 className="text-4xl md:text-6xl font-black mb-6 leading-tight">
                Kostenlose <span className="text-gradient">Premium Inhalte</span> durch tägliches Drehen!
              </h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                Du möchtest Premium-Features, aber gerade kein Geld ausgeben? Kein Problem! 
                Mit unserem Daily-Reward System kannst du dir jeden Tag Punkte sichern.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-6">
              <div className="glass p-6 rounded-3xl border-white/5 space-y-3">
                <div className="w-12 h-12 bg-brand-purple/20 rounded-2xl flex items-center justify-center text-brand-purple">
                  <Clock className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-white">Alle 24 Stunden</h4>
                <p className="text-gray-500 text-sm">
                  Komm jeden Tag zurück und drehe am Rad, um deine täglichen Punkte zu sammeln.
                </p>
              </div>

              <div className="glass p-6 rounded-3xl border-white/5 space-y-3">
                <div className="w-12 h-12 bg-brand-purple/20 rounded-2xl flex items-center justify-center text-brand-purple">
                  <Coins className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-white">Punkte sammeln</h4>
                <p className="text-gray-500 text-sm">
                  Sammle genug Punkte, um dir exklusive Premium-Artikel komplett gratis freizuschalten.
                </p>
              </div>
            </div>

            <div className="bg-brand-purple/10 border border-brand-purple/20 p-6 rounded-[32px] flex items-start gap-4">
              <div className="bg-brand-purple p-2 rounded-lg mt-1">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-300">
                  <span className="text-white font-bold">Pro-Tipp:</span> Wenn du die Premium Edition nicht kaufen möchtest, ist dies der perfekte Weg, um trotzdem in den Genuss aller Vorteile zu kommen. Bestimmte Premium-Artikel sind exklusiv über das Punktesystem erhältlich!
                </p>
              </div>
            </div>
          </motion.div>

          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative flex justify-center"
          >
            <div className="relative group w-full max-w-[380px]">
              {/* Multi-layered Glow Effect */}
              <div className="absolute -inset-1 bg-gradient-to-r from-brand-purple to-purple-600 rounded-[40px] blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200" />
              <div className="absolute -inset-4 bg-brand-purple/20 blur-3xl rounded-[40px] opacity-50 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative liquid-glass p-2 rounded-[40px] border-brand-purple/30 overflow-hidden shadow-2xl">
                <div className="aspect-[9/16] relative overflow-hidden rounded-[32px]">
                  <img 
                    src="/rd.png" 
                    alt="Daily Reward System" 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  {/* Glass Overlay for depth */}
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-bg/40 via-transparent to-white/5 pointer-events-none" />
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-12 h-12 bg-brand-purple rounded-2xl flex items-center justify-center shadow-lg shadow-brand-purple/40 animate-bounce">
                <Gift className="w-6 h-6 text-white" />
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
