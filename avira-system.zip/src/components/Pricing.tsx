import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, Crown, X } from 'lucide-react';

const perks = [
  'Alle Premium Mods inklusive',
  'Custom Waffen-Skins',
  'Exklusive Grafikmods',
  'Premium Soundboard-Packs',
  'Erweiterte Crosshair-Vorlagen',
  'Prioritäts-Updates',
  'Alle zukünftigen Features',
  'Premium Edition — einmalig zahlen',
];

export default function Pricing() {
  const [showModal, setShowModal] = useState(false);

  return (
    <section className="py-24 px-6 relative overflow-hidden">
      {/* Background Glow - Smoother radial gradient */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(139,92,246,0.05)_0%,transparent_70%)] -z-10" />
      
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-brand-purple text-xs font-bold tracking-widest uppercase mb-4 block">
            Premium Edition
          </span>
          <h2 className="text-4xl md:text-6xl font-black mb-6">Einmal zahlen, alles haben</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Mit der <span className="text-white font-semibold">Premium Edition</span> schaltest du alle exklusiven Features dauerhaft frei — 
            eine einmalige Zahlung für immer. Kein Abo, keine versteckten Kosten.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-xl mx-auto liquid-glass p-10 rounded-[40px] border-brand-purple/50 relative shadow-2xl shadow-glow-purple"
        >
          <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-brand-purple px-6 py-2 rounded-full flex items-center gap-2 font-bold text-sm shadow-xl shadow-brand-purple/40 glow-white">
            <Crown className="w-4 h-4" />
            Premium Edition
          </div>

          <div className="text-center mb-10">
            <div className="text-gray-500 font-bold uppercase tracking-widest text-xs mb-2">Premium Edition</div>
            <div className="text-6xl font-black mb-2 glow-white">29,99€</div>
            <div className="text-gray-400 text-sm">Einmalige Zahlung — kein Abo</div>
          </div>

          <div className="space-y-4 mb-10">
            {perks.map((perk) => (
              <div key={perk} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-brand-purple/20 flex items-center justify-center shadow-inner">
                  <Check className="w-3 h-3 text-brand-purple glow-purple" />
                </div>
                <span className="text-gray-300 font-medium">{perk}</span>
              </div>
            ))}
          </div>

          <button 
            onClick={() => setShowModal(true)}
            className="w-full bg-brand-purple hover:bg-brand-purple-dark text-white py-5 rounded-2xl font-black text-lg transition-all shadow-xl shadow-brand-purple/60 shadow-glow-purple flex items-center justify-center gap-3 active:scale-95"
          >
            Premium Edition kaufen — 29,99€
          </button>
        </motion.div>
      </div>

      {/* Purchase Modal */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowModal(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg liquid-glass p-8 rounded-[40px] border-brand-purple/50 shadow-2xl shadow-glow-purple"
            >
              <button
                onClick={() => setShowModal(false)}
                className="absolute top-6 right-6 text-gray-500 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-brand-purple/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Crown className="w-8 h-8 text-brand-purple" />
                </div>
                <h3 className="text-3xl font-black mb-2">Premium kaufen</h3>
                <p className="text-gray-400">So sicherst du dir deine Premium Edition</p>
              </div>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-brand-purple flex items-center justify-center font-bold shrink-0">1</div>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    Tritt unserem <a href="https://discord.gg/fx3tumNgCB" target="_blank" rel="noopener noreferrer" className="text-brand-purple font-bold underline">Discord Server</a> bei. Den Link findest du oben in der Navigation oder unten im Footer.
                  </p>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-brand-purple flex items-center justify-center font-bold shrink-0">2</div>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    Navigiere zum Channel <span className="text-white font-bold">#tickets</span> und öffne ein neues Ticket mit dem Betreff <span className="text-brand-purple font-bold">"Premium Kaufen"</span>.
                  </p>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-brand-purple flex items-center justify-center font-bold shrink-0">3</div>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    Ein Teammitglied wird sich umgehend bei dir melden, um die Zahlung und Details zu besprechen.
                  </p>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-brand-purple flex items-center justify-center font-bold shrink-0">4</div>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    Nach erfolgreichem Kauf erhältst du einen <span className="text-white font-bold">Aktivierungscode</span>, den du direkt in der AviraMods App einlösen kannst.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowModal(false)}
                className="w-full bg-brand-purple hover:bg-brand-purple-dark text-white py-4 rounded-2xl font-bold mt-10 transition-all shadow-lg shadow-brand-purple/20"
              >
                Verstanden
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
