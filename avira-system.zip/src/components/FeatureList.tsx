import { motion } from 'motion/react';
import { CheckCircle2, Zap, Shield, Cpu, Layout, Music, MousePointer2, Settings } from 'lucide-react';

const featureGroups = [
  {
    title: 'Visuals & Mods',
    features: [
      { name: 'Custom Crosshair Designer', desc: 'Erstelle dein eigenes Fadenkreuz mit Vorschau.' },
      { name: 'BloodFX Modifikationen', desc: 'Realistische Treffereffekte für mehr Immersion.' },
      { name: 'Custom Himmel (Skybox)', desc: 'Tausche den Standard-Himmel gegen epische Texturen.' },
      { name: 'Tracer Effekte', desc: 'Sichtbare Flugbahnen für deine Schüsse.' },
    ]
  },
  {
    title: 'Performance & PC',
    features: [
      { name: 'FPS Boost System', desc: 'Optimiere deine Windows-Einstellungen für maximale FPS.' },
      { name: 'Speicher-Clearer', desc: 'Befreie deinen RAM von unnötigem Ballast.' },
      { name: 'System Responsiveness', desc: 'Reduziere Input-Lag auf ein Minimum.' },
      { name: 'GPU & CPU Priorisierung', desc: 'Gib FiveM die volle Power deiner Hardware.' },
    ]
  },
  {
    title: 'Extras & Tools',
    features: [
      { name: 'Integriertes Soundboard', desc: 'Spiele Sounds direkt über dein Mikrofon ab.' },
      { name: 'Mod-Library', desc: 'Verwalte alle deine Mods an einem zentralen Ort.' },
      { name: 'Auto-Update System', desc: 'Bleibe immer auf dem neuesten Stand der Technik.' },
      { name: 'Discord Integration', desc: 'Teile deinen Status und verbinde dich mit anderen.' },
    ]
  }
];

export default function FeatureList() {
  return (
    <section id="features-list" className="py-24 px-6 bg-white/[0.02]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-brand-purple text-xs font-bold tracking-widest uppercase mb-4 block">
            Übersicht
          </span>
          <h2 className="text-4xl md:text-6xl font-black mb-6 glow-white">Alle Features im Überblick</h2>
          <p className="text-gray-400 max-w-2xl mx-auto mb-4">
            AviraMods bietet dir alles, was du für das perfekte FiveM Erlebnis brauchst.
          </p>
          <p className="text-brand-purple/60 text-sm font-bold italic">
            * Dies ist nur eine kleine Auswahl — es gibt noch vieles mehr zu entdecken!
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {featureGroups.map((group, gIndex) => (
            <motion.div
              key={group.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: gIndex * 0.1 }}
              className="liquid-glass p-8 rounded-[40px] border-white/5"
            >
              <h3 className="text-xl font-black mb-8 text-brand-purple glow-purple uppercase tracking-wider">
                {group.title}
              </h3>
              <div className="space-y-6">
                {group.features.map((feature, fIndex) => (
                  <div key={feature.name} className="group">
                    <div className="flex items-start gap-3 mb-1">
                      <CheckCircle2 className="w-5 h-5 text-brand-purple shrink-0 mt-0.5" />
                      <div className="font-bold text-white group-hover:text-brand-purple transition-colors">
                        {feature.name}
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 leading-relaxed ml-8">
                      {feature.desc}
                    </p>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
