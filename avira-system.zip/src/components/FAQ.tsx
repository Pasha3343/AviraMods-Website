import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    q: 'Was ist AviraMods?',
    a: 'AviraMods ist ein All-in-One Desktop-Tool für FiveM Spieler, das Modifikationen, PC-Optimierungen und nützliche Tools in einer Anwendung vereint.',
  },
  {
    q: 'Ist AviraMods kostenlos?',
    a: 'Ja, ca. 90% der Features sind komplett kostenlos nutzbar. Nur spezielle Premium-Mods und exklusive Funktionen erfordern die Premium Edition.',
  },
  {
    q: 'Was ist die Premium Edition und was bekomme ich dafür?',
    a: 'Die Premium Edition ist eine einmalige Zahlung, die dir dauerhaften Zugriff auf alle Premium-Features, exklusive Mods und Prioritäts-Updates gewährt.',
  },
  {
    q: 'Wie kaufe ich die Premium Edition?',
    a: 'Tritt unserem Discord-Server bei und öffne im Channel #tickets ein Ticket. Ein Teammitglied wird dir dann alle weiteren Schritte erklären. Nach der Zahlung erhältst du einen Key, den du in der App einlösen kannst.',
  },
  {
    q: 'Funktioniert AviraMods mit meinem FiveM Server?',
    a: 'Ja, AviraMods ist so konzipiert, dass es mit den meisten FiveM Servern kompatibel ist. Beachte jedoch immer die Regeln des jeweiligen Servers.',
  },
  {
    q: 'Kann ich durch AviraMods gebannt werden?',
    a: 'Unsere Mods sind sicher und für den Einsatz in FiveM optimiert. Dennoch erfolgt die Nutzung auf eigene Gefahr. Wir empfehlen, keine unfairen Vorteile zu nutzen.',
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 px-6">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-brand-purple text-xs font-bold tracking-widest uppercase mb-4 block">
            FAQ
          </span>
          <h2 className="text-4xl md:text-6xl font-black mb-6">Häufige Fragen</h2>
          <p className="text-gray-400">
            Alles was du über AviraMods wissen musst — ausführlich beantwortet.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="glass rounded-2xl overflow-hidden border-white/5"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-white/5 transition-colors"
              >
                <span className="font-bold">{faq.q}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-500 transition-transform ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="p-6 pt-0 text-gray-400 text-sm leading-relaxed border-t border-white/5">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center p-8 glass rounded-3xl">
          <p className="text-gray-400 mb-6">Noch eine Frage?</p>
          <button className="bg-brand-purple hover:bg-brand-purple-dark text-white px-8 py-3 rounded-xl font-bold transition-all">
            Discord beitreten
          </button>
        </div>
      </div>
    </section>
  );
}
