import { motion } from 'motion/react';
import { Download, Users, Heart } from 'lucide-react';
import { useFirebase } from '../lib/FirebaseContext';

export default function StatsSection() {
  const { config } = useFirebase();
  
  const stats = config?.stats || {
    downloads: '5.000+',
    members: '1.200+',
    satisfaction: '99%'
  };

  const statItems = [
    { 
      label: 'Downloads', 
      value: stats.downloads, 
      icon: Download,
      color: 'text-blue-400',
      bg: 'bg-blue-400/10'
    },
    { 
      label: 'Discord Members', 
      value: stats.members, 
      icon: Users,
      color: 'text-brand-purple',
      bg: 'bg-brand-purple/10'
    },
    { 
      label: 'Zufriedenheit', 
      value: stats.satisfaction, 
      icon: Heart,
      color: 'text-red-400',
      bg: 'bg-red-400/10'
    }
  ];

  return (
    <section className="py-20 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {statItems.map((item, index) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="liquid-glass p-8 rounded-[32px] border-white/5 flex flex-col items-center text-center group hover:border-brand-purple/30 transition-all duration-500"
            >
              <div className={`${item.bg} ${item.color} p-4 rounded-2xl mb-6 group-hover:scale-110 transition-transform duration-500 shadow-lg shadow-black/20`}>
                <item.icon className="w-8 h-8" />
              </div>
              <div className="text-4xl font-black mb-2 glow-white tracking-tighter">
                {item.value}
              </div>
              <div className="text-xs font-bold text-gray-500 uppercase tracking-widest">
                {item.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
