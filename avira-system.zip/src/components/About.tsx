import { useState, useEffect } from 'react';
import { motion } from 'motion/react';

const aboutCards = [
  {
    title: 'Die Idee',
    desc: 'Ich habe selbst lange FiveM gespielt und war frustriert, dass es kein einziges Tool gibt, das alles in einem vereint — Mods, Optimierung und Extras. So entstand AviraMods.',
  },
  {
    title: 'Warum ich das mache',
    desc: 'Ich möchte der Community etwas zurückgeben. Der Großteil ist kostenlos, weil jeder die Möglichkeit haben soll, das Beste aus seinem PC und FiveM herauszuholen.',
  },
  {
    title: 'Meine Ziele',
    desc: 'AviraMods soll das größte All-in-One Tool für FiveM und PC-Optimierung werden. Ständige neue Features, bessere Performance und eine starke Community.',
  },
  {
    title: 'Die Zukunft',
    desc: 'Regelmäßige Updates mit neuen Mods, Optimierungen und Features. Das Projekt wächst mit der Community — eure Wünsche fließen direkt ein.',
  },
];

export default function About() {
  const startDate = new Date('2026-03-01');
  const [daysElapsed, setDaysElapsed] = useState(0);

  useEffect(() => {
    const calculateDays = () => {
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - startDate.getTime());
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
      setDaysElapsed(diffDays);
    };

    calculateDays();
    const timer = setInterval(calculateDays, 1000 * 60 * 60); // Update every hour
    return () => clearInterval(timer);
  }, []);

  const months = Math.floor(daysElapsed / 30);
  const weeks = Math.floor((daysElapsed % 30) / 7);
  const days = daysElapsed % 7;

  return (
    <section id="about" className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Counter Section */}
        <div className="mb-32 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-purple/10 border border-brand-purple/20 text-brand-purple text-xs font-bold mb-8">
            <span className="w-2 h-2 rounded-full bg-brand-purple animate-pulse" />
            In aktiver Entwicklung
          </div>
          <h2 className="text-4xl md:text-6xl font-black mb-6">Ich arbeite seit...</h2>
          <p className="text-gray-400 mb-12">
            Jeden einzelnen Tag sitze ich an AviraMods — neue Features, Bugfixes, Verbesserungen. Und es hört nicht auf.
          </p>
          
          <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto mb-8">
            {[
              { val: months, label: months === 1 ? 'MONAT' : 'MONATE' },
              { val: weeks, label: weeks === 1 ? 'WOCHE' : 'WOCHEN' },
              { val: days, label: days === 1 ? 'TAG' : 'TAGE' },
            ].map((item) => (
              <div key={item.label} className="glass p-8 rounded-3xl shadow-glow-white">
                <div className="text-5xl font-black mb-2">{item.val}</div>
                <div className="text-[10px] font-bold text-gray-500 tracking-widest uppercase">{item.label}</div>
              </div>
            ))}
          </div>
          
          <div className="inline-block glass px-8 py-4 rounded-2xl shadow-glow-purple border-brand-purple/30">
            <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Insgesamt</div>
            <div className="text-3xl font-black text-brand-purple">{daysElapsed}</div>
            <div className="text-xs font-medium text-gray-400">Tage Entwicklungsarbeit</div>
            <div className="text-[10px] text-gray-600 mt-2">Gestartet am 1. März 2026 — Wird täglich aktualisiert</div>
          </div>
        </div>

        {/* About Me Section */}
        <div className="grid lg:grid-cols-[350px_1fr] gap-16 items-start">
          <div className="sticky top-32">
            <span className="text-brand-purple text-xs font-bold tracking-widest uppercase mb-4 block">
              Über mich
            </span>
            <h2 className="text-5xl font-black mb-8">Hey, ich bin Pasha</h2>
            
            <div className="relative mb-8 aspect-square rounded-[32px] overflow-hidden border border-brand-purple/20 shadow-xl shadow-glow-purple group max-w-[240px] mx-auto lg:mx-0">
              <img
                src="/logo.png"
                alt="Avira Logo"
                className="w-full h-full object-contain p-6 group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-bg/60 to-transparent" />
              <div className="absolute bottom-4 left-4">
                <div className="text-xl font-black">Pasha</div>
                <div className="text-brand-purple font-bold text-xs uppercase tracking-widest">Gründer & Entwickler</div>
              </div>
            </div>
            
            <p className="text-gray-400 leading-relaxed text-sm">
              Leidenschaftlicher Gamer und Entwickler. Ich arbeite jeden Tag daran, AviraMods besser zu machen 
              und euch das beste Erlebnis zu bieten.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {aboutCards.map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="liquid-glass p-10 rounded-[40px] hover:border-brand-purple/50 transition-all group hover:shadow-glow-purple"
              >
                <div className="w-10 h-10 bg-brand-purple/10 rounded-xl flex items-center justify-center mb-6 shadow-inner">
                  <div className="w-2 h-2 bg-brand-purple rounded-full glow-purple animate-pulse" />
                </div>
                <h3 className="text-2xl font-bold mb-4 glow-white">{card.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">
                  {card.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
