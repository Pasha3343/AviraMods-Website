import { motion } from 'motion/react';
import { DiscordIcon } from './Icons';
import { useFirebase } from '../lib/FirebaseContext';

const navLinks = [
  { name: 'Home', href: '#' },
  { name: 'Features', href: '#features-list' },
  { name: 'Bewertungen', href: '#reviews' },
  { name: 'FAQ', href: '#faq' },
  { name: 'Download', href: '#download' },
  { name: 'Über mich', href: '#about' },
];

export default function Navbar() {
  const { config } = useFirebase();
  const discordLink = config?.discordLink || "https://discord.gg/fx3tumNgCB";

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 flex justify-center p-4">
      <div className="liquid-glass flex items-center justify-between w-full max-w-7xl px-6 py-3 rounded-2xl shadow-glow-white border-white/20">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="Avira Logo" className="w-8 h-8 object-contain" />
          <span className="font-bold text-xl tracking-tight">AVIRAMODS</span>
        </div>

        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-sm font-medium text-gray-400 hover:text-white transition-colors"
            >
              {link.name}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <a
            href={discordLink}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:flex items-center gap-2 text-sm font-medium text-gray-400 hover:text-white transition-colors"
          >
            <DiscordIcon className="w-5 h-5" />
            Discord
          </a>
          <a 
            href="#pricing"
            className="bg-brand-purple hover:bg-brand-purple-dark text-white px-5 py-2 rounded-xl text-sm font-semibold transition-all shadow-xl shadow-brand-purple/40 shadow-glow-purple"
          >
            Premium holen
          </a>
        </div>
      </div>
    </nav>
  );
}
