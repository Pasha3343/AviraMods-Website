import { DiscordIcon } from './Icons';
import { useFirebase } from '../lib/FirebaseContext';

export default function Footer() {
  const { config } = useFirebase();
  const discordLink = config?.discordLink || "https://discord.gg/fx3tumNgCB";

  return (
    <footer className="relative z-20 bg-[#111113] border-t border-white/5 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6 relative">
        <div className="grid md:grid-cols-3 gap-12 mb-20">
          {/* Left Column */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <button 
                onClick={() => (window as any).openAdminPanel?.()}
                className="w-10 h-10 rounded-full bg-brand-purple/20 flex items-center justify-center text-brand-purple font-bold border border-brand-purple/30 shadow-glow-purple hover:scale-110 transition-transform active:scale-95 cursor-pointer"
                title="Admin Panel"
              >
                A
              </button>
              <span className="font-bold text-xl tracking-tight uppercase text-white">AVIRA SYSTEM</span>
            </div>
            <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
              Das All-in-One Desktop-Tool für FiveM Modifikationen und PC-Optimierung.
            </p>
          </div>

          {/* Middle Column */}
          <div>
            <h4 className="font-bold mb-6 text-white text-lg">Navigation</h4>
            <ul className="space-y-3 text-sm font-medium text-gray-500">
              <li><a href="#" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#features-list" className="hover:text-white transition-colors">Features</a></li>
              <li><a href="#pricing" className="hover:text-white transition-colors">Premium Edition</a></li>
              <li><a href="#download" className="hover:text-white transition-colors">Download</a></li>
              <li><a href="#about" className="hover:text-white transition-colors">Über mich</a></li>
            </ul>
          </div>

          {/* Right Column */}
          <div>
            <h4 className="font-bold mb-6 text-white text-lg">Info</h4>
            <ul className="space-y-3 text-sm font-medium text-gray-500">
              <li className="flex gap-2">Version: <span className="text-white font-bold">v1.2.0</span></li>
              <li className="flex gap-2">Entwickler: <span className="text-white font-bold">Pasha</span></li>
              <li className="flex gap-2">Plattform: <span className="text-white font-bold">Windows Desktop</span></li>
              <li className="flex gap-2">Preis: <span className="text-white font-bold">Großteil kostenlos</span></li>
            </ul>
          </div>
        </div>

        {/* Socials Row */}
        <div className="flex justify-center mb-10">
          <a
            href={discordLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-white/5 hover:bg-white/10 px-8 py-3 rounded-2xl transition-all border border-white/10 shadow-glow-purple"
          >
            <DiscordIcon className="w-5 h-5 text-brand-purple" />
            <span className="text-sm font-bold text-white">Discord beitreten</span>
          </a>
        </div>

        <div className="pt-10 border-t border-white/5 text-center">
          <div className="text-[11px] font-bold text-gray-500 uppercase tracking-widest flex items-center justify-center gap-2">
            © 2026 Avira System · Entwickelt mit <span className="text-red-500 animate-pulse">❤️</span> von Pasha
          </div>
          
          <div className="flex justify-center gap-6 mt-4 text-[9px] font-bold text-gray-600 uppercase tracking-widest">
            <a href="#" className="hover:text-brand-purple transition-colors">Impressum</a>
            <a href="#" className="hover:text-brand-purple transition-colors">Datenschutz</a>
            <a href="#" className="hover:text-brand-purple transition-colors">AGB</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
