import { motion } from 'motion/react';
import { Download, Rocket, Users, Monitor, Zap, TrendingUp } from 'lucide-react';

const stats = [
  { label: 'FiveM Mods', value: '20+', icon: Users },
  { label: 'PC Optimierungen', value: '15+', icon: Monitor },
  { label: 'Kostenlose Features', value: '90%', icon: Zap },
  { label: 'FPS Boost möglich', value: 'bis 40%', icon: TrendingUp },
];

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 px-6 overflow-hidden">
      {/* Background Glow - Smoother radial gradient */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[radial-gradient(circle_at_50%_0%,rgba(139,92,246,0.06)_0%,transparent_80%)] -z-10" />

      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-purple/10 border border-brand-purple/20 text-brand-purple text-xs font-bold mb-6">
            <span className="w-2 h-2 rounded-full bg-brand-purple animate-pulse" />
            Jetzt in der Beta Phase
          </div>
          
          <h1 className="text-6xl md:text-8xl font-black tracking-tighter mb-6 leading-[0.9]">
            <span className="text-white glow-white drop-shadow-[0_0_30px_rgba(255,255,255,0.3)]">AVIRA</span> <br />
            <span className="text-gradient glow-purple drop-shadow-[0_0_30px_rgba(139,92,246,0.3)]">MODS</span>
          </h1>
          
          <p className="text-lg text-gray-400 max-w-lg mb-10 leading-relaxed">
            Das ultimative All-in-One Desktop-Tool für FiveM Spieler. 
            Modifikationen, PC-Optimierung, Grafikmods, Soundboard 
            und mehr — alles in einer einzigen Anwendung.
          </p>
          
          <p className="text-sm text-gray-500 mb-8 italic">
            Entwickelt von einem Gamer für Gamer. Der Großteil ist komplett kostenlos — 
            weil jeder das Beste aus seinem System herausholen sollte.
          </p>
          
          <div className="flex flex-wrap gap-4">
            <a 
              href="#download"
              className="bg-brand-purple hover:bg-brand-purple-dark text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 transition-all shadow-xl shadow-brand-purple/40 shadow-glow-purple"
            >
              <Download className="w-5 h-5" />
              Jetzt herunterladen
            </a>
            <a 
              href="#features-list"
              className="glass hover:bg-white/10 text-white px-8 py-4 rounded-2xl font-bold transition-all shadow-glow-white flex items-center justify-center"
            >
              Features entdecken
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 gap-4"
        >
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="liquid-glass p-8 rounded-3xl group hover:border-brand-purple/50 transition-all shadow-lg hover:shadow-glow-purple"
            >
              <stat.icon className="w-8 h-8 text-brand-purple mb-4 group-hover:scale-110 transition-transform glow-purple" />
              <div className="text-3xl font-black mb-1 glow-white">{stat.value}</div>
              <div className="text-sm text-gray-500 font-medium uppercase tracking-wider">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
