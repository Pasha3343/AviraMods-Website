import { useCallback } from 'react';

const HOVER_SOUND = 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3'; // Subtle blip
const CLICK_SOUND = 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3'; // Tech click

export function useAudio() {
  const playHover = useCallback(() => {
    const audio = new Audio(HOVER_SOUND);
    audio.volume = 0.1;
    audio.play().catch(() => {});
  }, []);

  const playClick = useCallback(() => {
    const audio = new Audio(CLICK_SOUND);
    audio.volume = 0.2;
    audio.play().catch(() => {});
  }, []);

  return { playHover, playClick };
}
