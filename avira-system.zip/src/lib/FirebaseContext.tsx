import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User, signInWithPopup } from 'firebase/auth';
import { doc, onSnapshot, collection, query, orderBy, limit } from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from './firebase';

interface AppConfig {
  discordLink: string;
  stats?: {
    downloads: string;
    members: string;
    satisfaction: string;
  };
}

interface DownloadVersion {
  id: string;
  version: string;
  title: string;
  description: string;
  downloadUrl: string;
  isCurrent: boolean;
  createdAt: any;
}

interface FirebaseContextType {
  user: User | null;
  isAuthReady: boolean;
  config: AppConfig | null;
  downloads: DownloadVersion[];
  login: () => Promise<void>;
  logout: () => Promise<void>;
}

const FirebaseContext = createContext<FirebaseContextType | undefined>(undefined);

export function FirebaseProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [downloads, setDownloads] = useState<DownloadVersion[]>([]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setIsAuthReady(true);
    });
    return unsubscribe;
  }, []);

  // Listen to config
  useEffect(() => {
    const path = 'config/global';
    const unsubscribe = onSnapshot(doc(db, 'config', 'global'), (snapshot) => {
      if (snapshot.exists()) {
        setConfig(snapshot.data() as AppConfig);
      } else {
        // Default if not exists
        setConfig({ discordLink: 'https://discord.gg/fx3tumNgCB' });
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
    return unsubscribe;
  }, []);

  // Listen to downloads
  useEffect(() => {
    const path = 'downloads';
    const q = query(collection(db, path), orderBy('createdAt', 'desc'), limit(10));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as DownloadVersion[];
      setDownloads(docs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
    return unsubscribe;
  }, []);

  const login = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const logout = async () => {
    await auth.signOut();
  };

  return (
    <FirebaseContext.Provider value={{ user, isAuthReady, config, downloads, login, logout }}>
      {children}
    </FirebaseContext.Provider>
  );
}

export function useFirebase() {
  const context = useContext(FirebaseContext);
  if (context === undefined) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return context;
}
