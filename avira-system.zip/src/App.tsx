/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Pricing from './components/Pricing';
import Comparison from './components/Comparison';
import Reviews from './components/Reviews';
import FAQ from './components/FAQ';
import About from './components/About';
import DownloadSection from './components/Download';
import Footer from './components/Footer';
import Starfield from './components/Starfield';
import FeatureList from './components/FeatureList';
import DailyReward from './components/DailyReward';
import { FirebaseProvider } from './lib/FirebaseContext';
import AdminPanel from './components/AdminPanel';
import StatsSection from './components/StatsSection';
import { useAudio } from './lib/useAudio';
import { useEffect } from 'react';

function AppContent() {
  const { playHover, playClick } = useAudio();

  useEffect(() => {
    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'A' || target.tagName === 'BUTTON' || target.closest('a') || target.closest('button')) {
        playHover();
      }
    };

    const handleClick = () => {
      playClick();
    };

    window.addEventListener('mouseover', handleMouseOver);
    window.addEventListener('click', handleClick);

    return () => {
      window.removeEventListener('mouseover', handleMouseOver);
      window.removeEventListener('click', handleClick);
    };
  }, [playHover, playClick]);

  return (
    <div className="min-h-screen selection:bg-brand-purple selection:text-white relative">
      <Starfield />
      <Navbar />
      <main className="relative z-10">
        <Hero />
        <StatsSection />
        <Features />
        <FeatureList />
        <DailyReward />
        <Pricing />
        <Reviews />
        <FAQ />
        <About />
        <DownloadSection />
      </main>
      <Footer />
      <AdminPanel />
    </div>
  );
}

export default function App() {
  return (
    <FirebaseProvider>
      <AppContent />
    </FirebaseProvider>
  );
}

